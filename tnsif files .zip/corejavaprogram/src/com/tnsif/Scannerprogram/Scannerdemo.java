package com.tnsif.Scannerprogram;
import java.util.Scanner;

public class Scannerdemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your uid");
		 int Usn=sc.nextInt();
		 
		 System.out.println("enter your name");
		String name=sc.next();
	}

}
