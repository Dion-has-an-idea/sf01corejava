package com.tnsif.abstractors;

public class demo {
	public static void main(String[] args) {
		square s=new square();
	System.out.println(s);
//		Shape p1 =new Shape();
		
//		Shape p=new Square(4.5f);
		s.calarea();
		s.show();
	}

}
