package com.tnsif.accessmod;

public class demo {
	public static void main(String[] args) {
		publicdemo p=new publicdemo ();
		System.out.println(p.a);
		
	//	System.out.println(p.name);
		
		System.out.println(p.s);
		
		System.out.println(p.u);
	}


}
