package com.tnsif.collectionframework;

public class setoperations {
	public static void main(String[] args) {
		setdemo.operations();
	}
}
