package com.tnsif.comparator;

public class Student {

}
