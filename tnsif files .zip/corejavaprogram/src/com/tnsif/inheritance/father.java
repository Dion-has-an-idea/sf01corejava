package com.tnsif.inheritance;

public class father {
int money =7000;
String car="BMW";
void driving()
{
	System.out.println("colour colour which colour do you choose");
}
}