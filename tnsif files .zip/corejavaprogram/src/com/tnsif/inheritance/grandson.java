package com.tnsif.inheritance;

public class grandson extends son {
	
	public static void main (String[] args)
	 {
	grandson sn=new grandson ();
	 System.out.println(sn.car);
	 System.out.println(sn.money);
	 System.out.println(sn.random);
	 sn.driving();
	 
}
}