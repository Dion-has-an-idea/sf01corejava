package com.tnsif.inheritance;

public class son extends father{
	int random=988789;
 public static void main (String[] args)
 {
	 son s=new son ();
	 System.out.println(s.car);
	 System.out.println(s.money);
	 s.driving();
 }
}
