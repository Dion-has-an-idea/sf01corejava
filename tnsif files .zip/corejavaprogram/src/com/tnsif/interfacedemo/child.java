package com.tnsif.interfacedemo;

public class child implements interfcaetwo{
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args)
	{
		child d=new child();
		d.show();
		d.print();
	}

	

}
