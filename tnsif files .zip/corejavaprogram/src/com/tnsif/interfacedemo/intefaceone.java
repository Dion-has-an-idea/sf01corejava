package com.tnsif.interfacedemo;

public interface intefaceone {
	
		
		void print();
		
}
