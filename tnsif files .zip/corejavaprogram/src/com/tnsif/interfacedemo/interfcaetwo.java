package com.tnsif.interfacedemo;

public interface interfcaetwo extends intefaceone  {
	void show();

}
