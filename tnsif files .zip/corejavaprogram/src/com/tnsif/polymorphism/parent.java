package com.tnsif.polymorphism;

public class parent {
 int a = 89;
 void drinking ()
 {
	 System.out.println("juice");
 }
 
}
