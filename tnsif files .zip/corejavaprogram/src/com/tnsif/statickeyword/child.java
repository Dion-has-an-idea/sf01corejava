package com.tnsif.statickeyword;

public class child extends finalkeyword{
	
	@Override
	void show() {
		System.out.println("java");
	}


}