package com.tnsif.statickeyword;

public class employee {
	static {
		System.out.println("static ");
	}
	
	public static void main(String[] args) {
		System.out.println("welcome");
	}

}
