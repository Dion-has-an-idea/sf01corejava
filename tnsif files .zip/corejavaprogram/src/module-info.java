/**
 * 
 */
/**
 * 
 */
module corejavaprogram {
}